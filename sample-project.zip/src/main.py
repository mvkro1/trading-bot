# Main script

print('Hello, world!')